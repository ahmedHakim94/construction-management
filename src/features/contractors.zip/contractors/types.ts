import { z } from "zod";
import { contractorSchema } from "./schemas/contractor.schema";

export type ContractorStatus = "ACTIVE" | "INACTIVE";

export interface Contractor {
  id: number;
  name: string;
  phone: string;
  status: ContractorStatus;
  createdAt: string;
}

export type ContractorFormValues = z.infer<typeof contractorSchema>;

export interface ExternalContractor {
  id: string;
  name: string;
  createdAt: string;
}

export interface ExternalContractorFormValues {
  name: string;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
}