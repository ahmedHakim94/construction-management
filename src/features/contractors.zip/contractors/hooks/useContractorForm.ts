import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useTranslation } from "react-i18next";
import type { SelectOption } from "@/components/ui/AppSelect";
import { contractorSchema } from "../schemas/contractor.schema";
import type { Contractor, ContractorFormValues } from "../types";
import { equipmentTypeService } from "@/features/settings/equipment-type/services/equipmentType.service";
import { equipmentService } from "@/features/equipment/services/equipment.service";
import { useGetAllEquipmentTypeQuery } from "@/features/settings/equipment-type/services/equipmentType.api";
import { useGetAllEquipmentQuery } from "@/features/equipment/services/equipment.api";

interface UseContractorFormProps {
  open: boolean;
  mode: "create" | "edit";
  contractor?: Contractor;
  onClose: () => void;
  onSubmit: (values: ContractorFormValues) => Promise<void>;
}

export function useContractorForm({
  open,
  mode,
  contractor,
  onClose,
  onSubmit,
}: UseContractorFormProps) {
  const { t, i18n } = useTranslation();
  const isArabic = i18n.language === "ar";

  const [loading, setLoading] = useState(false);
  const [equipmentTypeOptions, setEquipmentTypeOptions] = useState<
    readonly SelectOption[]
  >([]);

  const methods = useForm<ContractorFormValues>({
    resolver: zodResolver(contractorSchema),
    defaultValues: {
      name: "",
      phone: "",
      notes: "",
      status: "ACTIVE",
      equipment: [],
    },
  });

  const { handleSubmit, reset } = methods;

  const { data: equipment_type } = useGetAllEquipmentTypeQuery();

  useEffect(() => {
    if (equipment_type) {
      setEquipmentTypeOptions(
        equipment_type.map((item) => ({
          value: String(item.id),
          label: item.name,
        })),
      );
    }
  }, [equipment_type]);

  const { data: equipmentsList } = useGetAllEquipmentQuery();

  useEffect(() => {
    async function loadContractorEquipment() {
      if (open) {
        let contractorEq: {
          id?: string;
          equipmentTypeId: string;
          model?: string;
          plateNumber?: string;
          hourlyPrice: number;
          notes?: string;
        }[] = [];
        if (mode === "edit" && contractor) {
          try {
            contractorEq = equipmentsList
              ?.filter((eq) => eq.contractorId === contractor.id)
              .map((eq) => ({
                id: eq.id,
                equipmentTypeId: eq.equipmentTypeId,
                model: eq.model || "",
                plateNumber: eq.plateNumber || "",
                hourlyPrice: eq.hourlyPrice,
                notes: eq.notes || "",
              }));
          } catch (error) {
            console.error("Failed to load contractor equipment:", error);
          }
        }

        reset({
          name: contractor?.name ?? "",
          phone: contractor?.phone ?? "",
          notes: contractor?.notes ?? "",
          status: contractor?.status ?? "ACTIVE",
          equipment: contractorEq,
        });
      }
    }

    loadContractorEquipment();
  }, [contractor, open, reset, mode, equipmentsList]);

  const submit = async (values: ContractorFormValues) => {
    setLoading(true);
    try {
      await onSubmit(values);
      reset({
        name: "",
        phone: "",
        notes: "",
        status: "ACTIVE",
        equipment: [],
      });
      onClose();
    } catch (error) {
      console.error("Failed to submit contractor form:", error);
    } finally {
      setLoading(false);
    }
  };

  return {
    methods,
    loading,
    equipmentTypeOptions,
    submit,
    handleSubmit,
    isArabic,
    t,
  };
}
